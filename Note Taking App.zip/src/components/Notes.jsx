import React from "react";

function Notes() {
  return (
    <div className="note">
      <h1>This is the React Bootcamp</h1>
      <p>
        All the students who complete the Bootcamp with complete attendance and
        project submission will be rewarded certificates from us.
      </p>
      <p>Made by Sarthak Sinha</p>
    </div>
  );
}

export default Notes;
